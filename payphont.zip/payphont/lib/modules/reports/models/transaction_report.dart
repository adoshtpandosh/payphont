const String content = '''class TransactionReport {
  final String id;
  final double amount;
  final String description;
  final DateTime date;
  final String category;

  TransactionReport({
    required this.id,
    required this.amount,
    required this.description,
    required this.date,
    required this.category,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'amount': amount,
        'description': description,
        'date': date.toIso8601String(),
        'category': category,
      };
}''';
const String content = '''import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../finance/models/transaction_model.dart';

/// Map<dayOfMonth, netAmount>
final monthlyChartProvider = Provider<Map<int, double>>((ref) {
  final box = Hive.box('transactions');
  final now = DateTime.now();
  final daysInMonth = DateTime(now.year, now.month + 1, 0).day;

  final data = <int, double>{for (int d = 1; d <= daysInMonth; d++) d: 0.0};

  for (final tx in box.values.cast<TransactionModel>()) {
    if (tx.date.year == now.year && tx.date.month == now.month) {
      final day = tx.date.day;
      final net = tx.type == TransactionType.income ? tx.amount : -tx.amount;
      data[day] = (data[day] ?? 0) + net;
    }
  }
  return data;
});''';